var score = 0;
var scoreText;

const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  parent: "game_run",
  physics: {
    default: "arcade",
    arcade: {
      gravity: { y: 300 },
      debug: false,
    },
  },
  scene: {
    preload: preload,
    create: create,
    update: update,
  },
};

const game = new Phaser.Game(config);

function preload() {
  this.load.image("estrela", "../assets/star.png");
  this.load.image("ceu", "../assets/image1.png");
  this.load.image("platform", "../assets/platform.png");
  this.load.image("bandeiraAngola", "../assets/BdAngola.png");
  this.load.image("insigniaAngola", "../assets/in.png");
  this.load.image("palanca", "../assets/palanca.png");
  this.load.spritesheet("jogador", "../assets/dude4.png", {
    frameWidth: 37.3,
    frameHeight: 48,
  });
}

function create() {
  this.add.image(this.sys.canvas.width, this.sys.canvas.height / 2, "ceu");

  chao = this.physics.add.staticGroup();
  chao
    .create(0, this.sys.canvas.height, "platform")
    .setScale(19, 3)
    .refreshBody();

  palanca = this.physics.add.sprite(1000, 0, "palanca");
  palanca.setCollideWorldBounds(true);
  this.physics.add.collider(palanca, chao);

  player = this.physics.add.sprite(100, 450, "jogador");
  player.setBounce(0.2);
  player.setCollideWorldBounds(true);
  this.physics.add.collider(player, chao);
  this.cameras.main.setBounds(0, 0, 2100, 600);
  this.physics.world.setBounds(0, 0, 2100, 600);
  this.cameras.main.startFollow(player);
  this.physics.add.collider(player, palanca);

  this.anims.create({
    key: "left",
    frames: this.anims.generateFrameNumbers("jogador", { start: 0, end: 7 }),
    frameRate: 10,
    repeat: -1,
  });

  this.anims.create({
    key: "turn",
    frames: [{ key: "jogador", frame: 9 }],
    frameRate: 20,
  });

  this.anims.create({
    key: "right",
    frames: this.anims.generateFrameNumbers("jogador", { start: 13, end: 21 }),
    frameRate: 10,
    repeat: -1,
  });

  estrelas = this.physics.add.group({
    key: "estrela",
    repeat: 50,
    setXY: { x: 38, y: 0, stepX: 100 },
  });

  estrelas.children.iterate(function (child) {
    child.setBounceY(Phaser.Math.FloatBetween(0.2, 0.4));
  });

  bandeiras = this.physics.add.group({
    key: "bandeiraAngola",
    repeat: 50,
    setXY: { x: 84, y: 0, stepX: 100 },
  });

  bandeiras.children.iterate(function (child) {
    child.setBounceY(Phaser.Math.FloatBetween(0.2, 0.4));
  });

  this.physics.add.collider(bandeiras, chao);
  this.physics.add.collider(estrelas, chao);
  this.physics.add.collider(player, estrelas, recolherItems, null, this);
  this.physics.add.collider(player, bandeiras, recolherItems, null, this);

  //IMPLEMENTANDO A PONTUAÇÃO
  scoreText = this.add.text(20, 20, "Score: 0", {
    fontSize: "32px",
    fill: "#000",
  });
  function recolherItems(jogador, item) {
    item.disableBody(true, true);
    score += 5;
    scoreText.setText("Score: " + score);
  }
}

function update() {
  cursors = this.input.keyboard.createCursorKeys();

  if (cursors.left.isDown) {
    player.setVelocityX(-160);
    player.anims.play("left", true);
  } else if (cursors.right.isDown) {
    player.setVelocityX(160);
    player.anims.play("right", true);
  } else {
    player.setVelocityX(0);
    player.anims.play("turn");
  }
  if (cursors.up.isDown && player.body.touching.down) {
    player.setVelocityY(-220);
  }
}
